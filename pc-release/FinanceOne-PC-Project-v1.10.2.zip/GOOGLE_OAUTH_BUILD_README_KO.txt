FinanceOne PC Google OAuth 빌드 안내

목표
- 사용자는 OAuth JSON을 직접 불러오지 않고 Google 계정 연결 버튼만 사용
- 만료된 access token도 refresh token으로 자동 갱신
- 인증정보가 빠진 불완전 PC 실행파일은 빌드 단계에서 차단

Windows OAuth 클라이언트
- 유형: 데스크톱
- 클라이언트 ID: 100084332728-f9bkversf91mi03bf1e9j2b39emfqtde.apps.googleusercontent.com
- scope: openid, email, profile, drive.appdata
- 시스템 브라우저와 PKCE를 사용

빌드
- Google Drive / 가계부 / 빌드 인증정보에 보관된 FinanceOne-Windows-OAuth-build-config.json을 준비
- FINANCEONE_GOOGLE_OAUTH_JSON 환경 변수에 위 JSON의 로컬 경로를 지정
- npm run build:portable 실행
- 빌드 스크립트가 임시 런타임 설정을 만들고 패키징 후 원본 임시 파일을 삭제
- client_secret이 없거나 다른 클라이언트 ID이면 빌드 실패

보안 및 배포
- OAuth JSON과 client_secret은 GitHub, 프로젝트 ZIP, 로그에 포함하지 않음
- 완성된 데스크톱 앱에는 토큰 갱신에 필요한 런타임 설정만 포함
- Desktop 설치 앱의 client_secret은 배포 앱에서 완전한 비밀로 취급할 수 없으므로 Google 계정 비밀번호나 OAuth 토큰을 함께 저장하지 않음
- OAuth access token과 refresh token은 사용자 PC의 AppData에만 저장
- Google Drive appDataFolder만 사용
