const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const crypto = require('node:crypto');

app.setName('FinanceOne');
let db;
let mainWindow;
let googleAutoTimer;
let pendingGoogleState;
let lastGoogleUploadAt = 0;
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

const userFile = name => path.join(app.getPath('userData'), name);
const validState = state => !!state && typeof state === 'object' && !Array.isArray(state) &&
  ['categories','payments','accounts','transactions','budgets','subscriptions'].every(k => Array.isArray(state[k])) &&
  (state.foodPurchases == null || Array.isArray(state.foodPurchases)) &&
  (state.foodConsumptions == null || Array.isArray(state.foodConsumptions)) &&
  state.transactions.length <= 100000 && state.categories.length <= 10000;

function safeJson(state) {
  if (!validState(state)) throw new Error('Invalid application state');
  const json = JSON.stringify(state);
  if (Buffer.byteLength(json, 'utf8') > 10 * 1024 * 1024) throw new Error('Application state exceeds 10MB');
  return json;
}

const GOOGLE_SCOPES = [
  'openid',
  'email',
  'profile',
  'https://www.googleapis.com/auth/drive.appdata'
];
const GOOGLE_DESKTOP_CLIENT_ID = '100084332728-f9bkversf91mi03bf1e9j2b39emfqtde.apps.googleusercontent.com';
const GOOGLE_RUNTIME_CONFIG_NAME = 'google-oauth-runtime.json';
const GOOGLE_BACKUP_NAME = 'FinanceOne-data.json';
const GOOGLE_BACKUP_PREFIX = 'financeone-backup-';

function googleConfig() {
  const file = [
    userFile('google-oauth-client.json'),
    path.join(process.resourcesPath, GOOGLE_RUNTIME_CONFIG_NAME),
    path.join(process.resourcesPath, 'google-oauth-client.json'),
    path.join(__dirname, 'build', GOOGLE_RUNTIME_CONFIG_NAME),
    path.join(__dirname, 'google-oauth-client.json')
  ].find(candidate => fs.existsSync(candidate));
  if (!file) {
    const client_secret = String(process.env.FINANCEONE_GOOGLE_CLIENT_SECRET || '').trim();
    if (client_secret) return { client_id: GOOGLE_DESKTOP_CLIENT_ID, client_secret };
    throw new Error('Google OAuth 인증정보가 누락된 빌드입니다. FinanceOne 최신 배포본을 다시 설치하세요.');
  }
  const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
  const config = parsed.installed || parsed;
  if (config?.client_id !== GOOGLE_DESKTOP_CLIENT_ID || !String(config?.client_secret || '').trim()) {
    throw new Error('Google OAuth 인증정보가 올바르지 않습니다. FinanceOne Windows용 설정인지 확인하세요.');
  }
  return config;
}

function googleConfigFile() { return userFile('google-oauth-client.json'); }
function hasGoogleConfig() {
  try {
    const config = googleConfig();
    return config.client_id === GOOGLE_DESKTOP_CLIENT_ID && !!config.client_secret;
  } catch { return false; }
}
async function googleImportConfig() {
  const picked = await dialog.showOpenDialog(mainWindow, {
    title: 'Google OAuth 설정 파일 선택',
    properties: ['openFile'],
    filters: [{ name: 'Google OAuth JSON', extensions: ['json'] }]
  });
  if (picked.canceled || !picked.filePaths[0]) return { configured: hasGoogleConfig(), canceled: true };
  let parsed;
  try { parsed = JSON.parse(fs.readFileSync(picked.filePaths[0], 'utf8')); }
  catch { throw new Error('선택한 파일을 읽을 수 없습니다. Google Cloud에서 받은 JSON 파일인지 확인하세요.'); }
  if (!parsed?.installed?.client_id || !parsed?.installed?.client_secret) {
    throw new Error('데스크톱 앱용 Google OAuth JSON 파일이 아닙니다.');
  }
  if (parsed.installed.client_id !== GOOGLE_DESKTOP_CLIENT_ID) {
    throw new Error('FinanceOne Windows용 OAuth JSON이 아닙니다. Google Cloud에서 FinanceOne Windows 클라이언트의 JSON을 내려받아 선택하세요.');
  }
  const temp = `${googleConfigFile()}.tmp`;
  fs.writeFileSync(temp, JSON.stringify({ installed: parsed.installed }), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temp, googleConfigFile());
  return { configured: true, canceled: false };
}

function googleTokenFile() { return userFile('google-oauth-token.json'); }
function loadGoogleTokens() {
  try { return JSON.parse(fs.readFileSync(googleTokenFile(), 'utf8')); }
  catch { return null; }
}
function saveGoogleTokens(tokens) {
  const temp = `${googleTokenFile()}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(tokens), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(temp, googleTokenFile());
}

async function googleTokenRequest(params) {
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error_description || result.error || 'Google 토큰 발급에 실패했습니다.');
  return result;
}

async function googleAccessToken() {
  const tokens = loadGoogleTokens();
  if (!tokens) throw new Error('Google 계정을 먼저 연결하세요.');
  if (tokens.access_token && Number(tokens.expires_at) > Date.now() + 60_000) return tokens.access_token;
  if (!tokens.refresh_token) throw new Error('Google 로그인이 만료되었습니다. 다시 연결하세요.');
  const config = googleConfig();
  const refreshParams = {
    client_id: config.client_id,
    client_secret: config.client_secret,
    refresh_token: tokens.refresh_token,
    grant_type: 'refresh_token'
  };
  const refreshed = await googleTokenRequest(refreshParams);
  const next = { ...tokens, ...refreshed, refresh_token: tokens.refresh_token, expires_at: Date.now() + refreshed.expires_in * 1000 };
  saveGoogleTokens(next);
  return next.access_token;
}

async function googleApi(url, options = {}) {
  const accessToken = await googleAccessToken();
  const response = await fetch(url, { ...options, headers: { ...(options.headers || {}), authorization: `Bearer ${accessToken}` } });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error?.message || `Google API 오류 (${response.status})`);
  }
  return response;
}

async function googleLogin() {
  const config = googleConfig();
  const state = crypto.randomBytes(24).toString('hex');
  const verifier = crypto.randomBytes(48).toString('base64url');
  const challenge = crypto.createHash('sha256').update(verifier).digest('base64url');
  return new Promise((resolve, reject) => {
    let finished = false;
    const finish = (error, value) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      server.close();
      if (error) reject(error); else resolve(value);
    };
    const server = http.createServer(async (request, response) => {
      try {
        const incoming = new URL(request.url, 'http://127.0.0.1');
        if (incoming.pathname !== '/oauth2callback') {
          response.writeHead(404).end();
          return;
        }
        if (incoming.searchParams.get('state') !== state) throw new Error('Google 로그인 보안 확인에 실패했습니다.');
        const code = incoming.searchParams.get('code');
        const oauthError = incoming.searchParams.get('error');
        if (oauthError || !code) throw new Error(oauthError === 'access_denied' ? 'Google 로그인이 취소되었습니다.' : 'Google 인증 코드를 받지 못했습니다.');
        const redirectUri = `http://127.0.0.1:${server.address().port}/oauth2callback`;
        const tokenParams = {
          client_id: config.client_id,
          client_secret: config.client_secret,
          code,
          code_verifier: verifier,
          grant_type: 'authorization_code',
          redirect_uri: redirectUri
        };
        const token = await googleTokenRequest(tokenParams);
        const profileResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', { headers: { authorization: `Bearer ${token.access_token}` } });
        const profile = profileResponse.ok ? await profileResponse.json() : {};
        const stored = { ...token, expires_at: Date.now() + token.expires_in * 1000, email: profile.email || '', name: profile.name || '' };
        saveGoogleTokens(stored);
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
        response.end('<!doctype html><meta charset="utf-8"><title>FinanceOne</title><body style="font-family:sans-serif;text-align:center;padding:60px"><h2>Google 계정 연결 완료</h2><p>이 창을 닫고 FinanceOne으로 돌아가세요.</p></body>');
        finish(null, { connected: true, email: stored.email, name: stored.name });
      } catch (error) {
        response.writeHead(400, { 'content-type': 'text/html; charset=utf-8' });
        response.end('<!doctype html><meta charset="utf-8"><h2>Google 계정 연결에 실패했습니다.</h2><p>FinanceOne으로 돌아가 다시 시도하세요.</p>');
        finish(error);
      }
    });
    server.listen(0, '127.0.0.1', async () => {
      const redirectUri = `http://127.0.0.1:${server.address().port}/oauth2callback`;
      const auth = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      auth.search = new URLSearchParams({
        client_id: config.client_id,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: GOOGLE_SCOPES.join(' '),
        access_type: 'offline',
        prompt: 'consent',
        state,
        code_challenge: challenge,
        code_challenge_method: 'S256'
      }).toString();
      try { await shell.openExternal(auth.toString()); }
      catch (error) { finish(error); }
    });
    server.on('error', error => finish(error));
    const timer = setTimeout(() => finish(new Error('Google 로그인 시간이 초과되었습니다.')), 5 * 60 * 1000);
  });
}

async function googleStatus() {
  const tokens = loadGoogleTokens();
  const configured = hasGoogleConfig();
  return tokens && configured
    ? { connected: true, configured: true, email: tokens.email || '', name: tokens.name || '', appVersion: app.getVersion() }
    : { connected: false, configured, needsConfig: !!tokens && !configured, appVersion: app.getVersion() };
}

async function googleBackups() {
  const params = new URLSearchParams({
    spaces: 'appDataFolder',
    q: 'trashed=false',
    fields: 'files(id,name,createdTime,modifiedTime,size,appProperties)',
    orderBy: 'modifiedTime desc',
    pageSize: '100'
  });
  const response = await googleApi(`https://www.googleapis.com/drive/v3/files?${params}`);
  const result = await response.json();
  return (result.files || []).filter(file => file.name === GOOGLE_BACKUP_NAME || file.name === 'financeone-backup.json' || file.name.startsWith(GOOGLE_BACKUP_PREFIX)).map(file => ({
    ...file,
    appVersion: file.appProperties?.appVersion || '이전 버전'
  }));
}

async function googleListBackups() {
  const files = await googleBackups();
  return { files, lastBackupTime: files[0]?.modifiedTime || '' };
}

async function findGoogleBackup() {
  const params = new URLSearchParams({
    spaces: 'appDataFolder',
    q: `name='${GOOGLE_BACKUP_NAME}' and trashed=false`,
    fields: 'files(id,name,modifiedTime)',
    orderBy: 'modifiedTime desc',
    pageSize: '1'
  });
  const response = await googleApi(`https://www.googleapis.com/drive/v3/files?${params}`);
  const result = await response.json();
  return result.files?.[0] || null;
}

async function googleUpload(state) {
  safeJson(state);
  const createdAt = new Date().toISOString();
  const stamp = createdAt.replace(/[-:]/g,'').replace('T','-').slice(0,15);
  const json = JSON.stringify({ appName:'FinanceOne', appVersion:app.getVersion(), schemaVersion:5, createdAt, deviceInfo:`Windows ${process.arch}`, data:state });
  if (Buffer.byteLength(json, 'utf8') > 10 * 1024 * 1024) throw new Error('백업 데이터가 10MB를 초과했습니다.');
  const boundary = `financeone_${crypto.randomBytes(12).toString('hex')}`;
  const metadata = { name: `${GOOGLE_BACKUP_PREFIX}${stamp}.json`, parents: ['appDataFolder'], mimeType: 'application/json', appProperties:{appVersion:app.getVersion(),schemaVersion:'5'} };
  const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${json}\r\n--${boundary}--`;
  const response = await googleApi('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime,modifiedTime,size', {
    method: 'POST', headers: { 'content-type': `multipart/related; boundary=${boundary}` }, body
  });
  const result = await response.json();
  lastGoogleUploadAt = Date.now();
  return { ...result, lastBackupTime: createdAt };
}

function scheduleGoogleAutoUpload(state) {
  if (state?.settings?.googleAutoSync !== true || !loadGoogleTokens()) return;
  pendingGoogleState = JSON.parse(safeJson(state));
  clearTimeout(googleAutoTimer);
  googleAutoTimer = setTimeout(async () => {
    const current = pendingGoogleState;
    pendingGoogleState = null;
    try {
      if (current) {
        const result = await googleUpload(current);
        if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('financeone:google-auto-uploaded', result);
      }
    }
    catch (error) { console.error('Google auto sync failed:', error.message); }
  }, 30 * 1000);
}

async function googleDownload() {
  const file = (await googleBackups())[0];
  if (!file) throw new Error('Google Drive에 저장된 FinanceOne 데이터가 없습니다.');
  return googleRestoreBackup(file.id);
}

async function googleRestoreBackup(fileId) {
  const response = await googleApi(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media`);
  const payload = await response.json();
  const state = payload?.data || payload;
  if (!validState(state)) throw new Error('Google Drive 데이터 형식이 올바르지 않습니다.');
  return { state, fileId };
}

async function googleDeleteBackup(fileId) {
  await googleApi(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`, { method:'DELETE' });
  return { success:true };
}

async function googleDisconnect() {
  const tokens = loadGoogleTokens();
  if (tokens) {
    const token = tokens.refresh_token || tokens.access_token;
    if (token) await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' } }).catch(() => {});
    fs.rmSync(googleTokenFile(), { force: true });
  }
  return { connected: false };
}

function dailyBackup(json) {
  const dir = userFile('backups');
  fs.mkdirSync(dir, { recursive: true });
  const target = path.join(dir, `financeone-${new Date().toISOString().slice(0,10)}.json`);
  const temp = `${target}.tmp`;
  fs.writeFileSync(temp, json, 'utf8');
  fs.renameSync(temp, target);
  fs.readdirSync(dir).filter(x => /^financeone-\d{4}-\d{2}-\d{2}\.json$/.test(x)).sort().reverse().slice(14)
    .forEach(name => fs.unlinkSync(path.join(dir, name)));
}

function openDatabase() {
  const file = userFile('financeone.sqlite');
  db = new DatabaseSync(file, { timeout: 5000, defensive: true });
  db.exec(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS app_state (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      json TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) STRICT;
  `);
}


async function exportBackupFile(state) {
  const json = safeJson(state);
  const picked = await dialog.showSaveDialog(mainWindow, {
    title: 'FinanceOne 백업 파일 저장',
    defaultPath: path.join(app.getPath('documents'), 'FinanceOneBackup.json'),
    filters: [{ name: 'FinanceOne Backup', extensions: ['json'] }]
  });
  if (picked.canceled || !picked.filePath) return { canceled: true };
  fs.writeFileSync(picked.filePath, json, 'utf8');
  return { canceled: false, filePath: picked.filePath };
}

async function importBackupFile() {
  const picked = await dialog.showOpenDialog(mainWindow, {
    title: 'FinanceOne 백업 파일 불러오기',
    properties: ['openFile'],
    filters: [{ name: 'FinanceOne Backup', extensions: ['json'] }]
  });
  if (picked.canceled || !picked.filePaths[0]) return { canceled: true };
  const text = fs.readFileSync(picked.filePaths[0], 'utf8');
  const state = JSON.parse(text);
  if (!validState(state)) throw new Error('백업 파일 형식이 올바르지 않습니다.');
  return { canceled: false, filePath: picked.filePaths[0], fileName: path.basename(picked.filePaths[0]), state };
}

function registerStorage() {
  ipcMain.handle('financeone:load', () => {
    const row = db.prepare('SELECT json FROM app_state WHERE id = 1').get();
    if (!row) return null;
    try { const state = JSON.parse(row.json); return validState(state) ? state : null; } catch { return null; }
  });
  ipcMain.handle('financeone:save', (_event, state) => {
    const json = safeJson(state);
    db.prepare(`
      INSERT INTO app_state (id, json, updated_at)
      VALUES (1, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(id) DO UPDATE SET json = excluded.json, updated_at = CURRENT_TIMESTAMP
    `).run(json);
    dailyBackup(json);
    scheduleGoogleAutoUpload(state);
    return true;
  });
  ipcMain.handle('financeone:info', () => ({
    databasePath: userFile('financeone.sqlite'),
    backupPath: userFile('backups'),
    backupCount: fs.existsSync(userFile('backups')) ? fs.readdirSync(userFile('backups')).filter(x=>x.endsWith('.json')).length : 0,
    version: app.getVersion()
  }));
  ipcMain.handle('financeone:google-status', () => googleStatus());
  ipcMain.handle('financeone:google-import-config', () => googleImportConfig());
  ipcMain.handle('financeone:google-login', () => googleLogin());
  ipcMain.handle('financeone:google-upload', (_event, state) => {
    clearTimeout(googleAutoTimer);
    pendingGoogleState = null;
    return googleUpload(state);
  });
  ipcMain.handle('financeone:google-download', () => googleDownload());
  ipcMain.handle('financeone:google-list-backups', () => googleListBackups());
  ipcMain.handle('financeone:google-restore-backup', (_event, fileId) => googleRestoreBackup(fileId));
  ipcMain.handle('financeone:google-delete-backup', (_event, fileId) => googleDeleteBackup(fileId));
  ipcMain.handle('financeone:google-disconnect', () => googleDisconnect());
  ipcMain.handle('financeone:export-backup', (_event, state) => exportBackupFile(state));
  ipcMain.handle('financeone:import-backup', () => importBackupFile());
  ipcMain.handle('financeone:stock-lookup', (_event, payload) => stockLookup(payload));
}

function createWindow() {
  const win = new BrowserWindow({
    icon: path.join(__dirname, 'build', 'icon.ico'),
    width: 1500,
    height: 950,
    minWidth: 680,
    minHeight: 600,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#f4f7fb',
    title: 'FinanceOne',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: false,
      navigateOnDragDrop: false,
      devTools: !app.isPackaged
    }
  });
  mainWindow = win;
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-attach-webview', event => event.preventDefault());
  win.webContents.on('will-navigate', (event, url) => {
    try { if (new URL(url).protocol !== 'file:') event.preventDefault(); }
    catch { event.preventDefault(); }
  });
  win.loadFile('index.html');
  win.once('ready-to-show', () => win.show());
}

app.on('second-instance', () => {
  if (!mainWindow) return;
  if (!mainWindow.isVisible()) mainWindow.show();
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.moveTop();
  mainWindow.focus();
});

async function stockLookup({symbol,date,currency}) {
  const normalized=String(symbol||'').trim().toUpperCase();
  if(!normalized||!/^\d{4}-\d{2}-\d{2}$/.test(String(date||''))) throw new Error('종목과 날짜를 확인하세요.');
  const start=Math.floor(new Date(`${date}T00:00:00Z`).getTime()/1000)-7*86400;
  const end=Math.floor(new Date(`${date}T23:59:59Z`).getTime()/1000)+86400;
  const y=await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(normalized)}?period1=${start}&period2=${end}&interval=1d&events=history`);
  if(!y.ok)throw new Error('종목 데이터를 가져오지 못했습니다.');
  const j=await y.json(),r=j?.chart?.result?.[0];let close=0;
  (r?.timestamp||[]).forEach((t,i)=>{const d=new Date(t*1000).toISOString().slice(0,10),c=r?.indicators?.quote?.[0]?.close?.[i];if(d<=date&&Number.isFinite(c))close=c});
  if(!close)throw new Error('해당 날짜 이전의 종가가 없습니다.');
  let exchangeRate=1;
  if(currency==='USD'){const f=await fetch(`https://api.frankfurter.app/${date}?from=USD&to=KRW`);if(!f.ok)throw new Error('환율을 가져오지 못했습니다.');exchangeRate=Number((await f.json())?.rates?.KRW)||1}
  return {symbol:normalized,closePrice:close,exchangeRate};
}

if (gotLock) 
app.whenReady().then(() => {
  openDatabase();
  registerStorage();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  clearTimeout(googleAutoTimer);
  if (db) db.close();
});
