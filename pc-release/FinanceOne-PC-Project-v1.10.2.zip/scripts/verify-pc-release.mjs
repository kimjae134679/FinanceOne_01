import fs from 'node:fs';

const read = path => fs.readFileSync(path, 'utf8');
const app = read('app.js');
const main = read('main.js');
const preload = read('preload.js');
const index = read('index.html');
const pkg = JSON.parse(read('package.json'));
const existingStockSpec = read('FOOD_EXISTING_STOCK_SPEC_v1_KO.md');
const releaseCss = read('release-v171.css') + read('release-v172.css');

const checks = [
  ['Windows OAuth 클라이언트 ID', main.includes('100084332728-f9bkversf91mi03bf1e9j2b39emfqtde.apps.googleusercontent.com')],
  ['PKCE 인증', main.includes("code_challenge_method: 'S256'") && main.includes('code_verifier: verifier')],
  ['client_secret 필수 검증', main.includes("!String(config?.client_secret || '').trim()") && main.includes('!!config.client_secret')],
  ['토큰 교환 client_secret 전달', main.includes('client_secret: config.client_secret') && !main.includes('if (config.client_secret) refreshParams.client_secret')],
  ['배포용 OAuth 리소스 경로', main.includes("path.join(process.resourcesPath, GOOGLE_RUNTIME_CONFIG_NAME)") && pkg.build.extraResources?.some(resource=>resource.to==='google-oauth-runtime.json')],
  ['Drive appDataFolder', main.includes("parents: ['appDataFolder']") && main.includes("spaces: 'appDataFolder'")],
  ['백그라운드 업로드 완료 전달', main.includes("webContents.send('financeone:google-auto-uploaded'") && preload.includes('onGoogleAutoUploaded') && app.includes('onGoogleAutoUploaded?.(recordGoogleUpload)')],
  ['중복 실행 시 기존 창 활성화', main.includes('requestSingleInstanceLock()') && main.includes("app.on('second-instance'")],
  ['원격 복원 선확인', app.includes('offerGoogleRestore(latest,{enableAutoOnRestore:true})')],
  ['업로드 원격 수정시간 기록', app.includes('result?.modifiedTime||result?.lastBackupTime')],
  ['식비 여러 식재료 선택', app.includes('data-food-meal-pick') && app.includes('purchaseIds.forEach(purchaseId=>')],
  ['완료 재고 숨김', app.includes('S.foodPurchases.filter(p=>!foodIsFinished(p)&&foodMatches(p))')],
  ['기존 재고 등록', app.includes('id="addExistingFood"') && app.includes("source:'existing',priceKnown")],
  ['구매일 미기록', app.includes("source==='existing'?'':") && app.includes('기존 보유 재고 · 구매일 미기록')],
  ['금액 미기록 계산 제외', app.includes('S.foodPurchases.filter(foodHasPrice)') && app.includes('가격이 있는 기록 기준')],
  ['동일 식품 독립 ID', app.includes('S.foodPurchases.push({id:uid()') && app.includes("purchaseId,type:'portion'")],
  ['먹은 기록 수정', app.includes('data-food-meal-edit')],
  ['거래 날짜 단기 기억', app.includes('TRANSACTION_DATE_MEMORY_MS=10*60*1000')],
  ['앱 캐시 버전', /app\.js\?v=\d+/.test(index)]
  ,['소비 캘린더 지출 강도', app.includes('calendarHeatStyle') && releaseCss.includes('--heat-color')]
  ,['반응형 차트', app.includes('class="bar-scroll"') && releaseCss.includes('var(--bar-count)')]
  ,['다크 모드 공통 보정', releaseCss.includes('.dark .budget-section-row') && releaseCss.includes('.dark .tabs button.active')]
  ,['공통 모달 닫기', app.includes('ensureModalCloseButtons') && releaseCss.includes('.modal-floating-close')]
];

for (const [label, passed] of checks) {
  if (!passed) throw new Error(`PC 기능 검증 실패: ${label}`);
}
if (!existingStockSpec.includes('같은 상품을 다시 등록하거나 새로 구매해도 각각 독립 재고로 저장')) {
  throw new Error('기존 재고 기능 기획서가 누락되었거나 구현 기준과 다릅니다.');
}

console.log(`PASS: FinanceOne PC v${pkg.version} OAuth·Drive·자동동기화·거래·식비 검증`);
