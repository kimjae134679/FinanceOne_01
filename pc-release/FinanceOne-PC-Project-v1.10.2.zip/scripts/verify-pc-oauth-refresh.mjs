import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync('main.js','utf8');
const start = source.indexOf('function googleConfig()');
const end = source.indexOf('async function googleApi(');
if (start < 0 || end < 0) throw new Error('OAuth 검증 대상 코드를 찾지 못했습니다.');

const slice = source.slice(start,end)
  .replace('async function googleTokenRequest(params) {','async function googleTokenRequest(params) { globalThis.__lastTokenParams = {...params}; return { access_token:"renewed", expires_in:3600 }; }\n/*')
  .replace(/\n}\n\nasync function googleAccessToken\(\)/,'\n*/\n\nasync function googleAccessToken()');

const files = new Map();
const sandbox = {
  globalThis:null,
  GOOGLE_DESKTOP_CLIENT_ID:'100084332728-f9bkversf91mi03bf1e9j2b39emfqtde.apps.googleusercontent.com',
  GOOGLE_RUNTIME_CONFIG_NAME:'google-oauth-runtime.json',
  process:{resourcesPath:'C:/FinanceOne/resources',env:{}},
  __dirname:'C:/FinanceOne/app',
  path:{join:(...parts)=>parts.join('/')},
  userFile:name=>`C:/FinanceOne/user/${name}`,
  fs:{
    existsSync:path=>files.has(path),
    readFileSync:path=>files.get(path),
    writeFileSync:(path,value)=>files.set(path,value),
    renameSync:(from,to)=>{files.set(to,files.get(from));files.delete(from)}
  },
  Date,
  Buffer,
  console
};
sandbox.globalThis=sandbox;

const runtimePath='C:/FinanceOne/resources/google-oauth-runtime.json';
const tokenPath='C:/FinanceOne/user/google-oauth-token.json';
files.set(runtimePath,JSON.stringify({installed:{client_id:sandbox.GOOGLE_DESKTOP_CLIENT_ID,client_secret:'runtime-secret'}}));
files.set(tokenPath,JSON.stringify({access_token:'expired',refresh_token:'refresh-token',expires_at:0,email:'user@example.com'}));

vm.runInNewContext(`${slice}\nglobalThis.__run=googleAccessToken;globalThis.__config=googleConfig;`,sandbox);
const token=await sandbox.__run();
if(token!=='renewed')throw new Error('만료 토큰 갱신 결과가 올바르지 않습니다.');
if(sandbox.__lastTokenParams?.client_secret!=='runtime-secret')throw new Error('토큰 갱신 요청에 client_secret이 없습니다.');
if(sandbox.__lastTokenParams?.refresh_token!=='refresh-token')throw new Error('refresh_token이 보존되지 않았습니다.');

files.delete(runtimePath);
let missingRejected=false;
try{sandbox.__config()}catch(error){missingRejected=/인증정보가 누락/.test(error.message)}
if(!missingRejected)throw new Error('인증정보가 없는 불완전 빌드를 차단하지 못했습니다.');

console.log('PASS: 만료 토큰 갱신에 Windows OAuth client_secret 전달');
