import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const clientId='100084332728-f9bkversf91mi03bf1e9j2b39emfqtde.apps.googleusercontent.com';
const sourcePath=process.env.FINANCEONE_GOOGLE_OAUTH_JSON;
let installed;
if(sourcePath){
  const parsed=JSON.parse(fs.readFileSync(sourcePath,'utf8'));
  installed=parsed.installed||parsed;
}else{
  installed={client_id:clientId,client_secret:String(process.env.FINANCEONE_GOOGLE_CLIENT_SECRET||'').trim()};
}
if(installed?.client_id!==clientId||!String(installed?.client_secret||'').trim()){
  throw new Error('FinanceOne Windows OAuth JSON 또는 FINANCEONE_GOOGLE_CLIENT_SECRET이 필요합니다.');
}

const runtimePath=path.join('build','google-oauth-runtime.json');
fs.writeFileSync(runtimePath,JSON.stringify({installed:{client_id:clientId,client_secret:installed.client_secret}}),{mode:0o600});
try{
  const command=process.platform==='win32'?'npx.cmd':'npx';
  const built=spawnSync(command,['electron-builder','--win','portable','--x64'],{stdio:'inherit',shell:false});
  if(built.status!==0)process.exit(built.status||1);
  const packed=path.join('dist','win-unpacked','resources','google-oauth-runtime.json');
  const verified=JSON.parse(fs.readFileSync(packed,'utf8'));
  if(verified?.installed?.client_id!==clientId||!verified?.installed?.client_secret)throw new Error('완성된 PC 패키지에 OAuth 인증정보가 없습니다.');
  console.log('PASS: 완성된 PC 패키지의 OAuth 갱신 설정 확인');
}finally{
  fs.rmSync(runtimePath,{force:true});
}
