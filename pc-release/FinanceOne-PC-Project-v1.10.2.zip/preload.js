const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('financeOne', {
  load: () => ipcRenderer.invoke('financeone:load'),
  save: state => ipcRenderer.invoke('financeone:save', state),
  info: () => ipcRenderer.invoke('financeone:info'),
  googleStatus: () => ipcRenderer.invoke('financeone:google-status'),
  googleImportConfig: () => ipcRenderer.invoke('financeone:google-import-config'),
  googleLogin: () => ipcRenderer.invoke('financeone:google-login'),
  googleUpload: state => ipcRenderer.invoke('financeone:google-upload', state),
  onGoogleAutoUploaded: callback => {
    const listener = (_event, result) => callback(result);
    ipcRenderer.on('financeone:google-auto-uploaded', listener);
    return () => ipcRenderer.removeListener('financeone:google-auto-uploaded', listener);
  },
  googleDownload: () => ipcRenderer.invoke('financeone:google-download'),
  listBackups: () => ipcRenderer.invoke('financeone:google-list-backups'),
  restoreBackup: ({fileId}) => ipcRenderer.invoke('financeone:google-restore-backup', fileId),
  deleteBackup: ({fileId}) => ipcRenderer.invoke('financeone:google-delete-backup', fileId),
  googleDisconnect: () => ipcRenderer.invoke('financeone:google-disconnect'),
  exportBackup: state => ipcRenderer.invoke('financeone:export-backup', state),
  importBackup: () => ipcRenderer.invoke('financeone:import-backup'),
  stockLookup: (symbol,date,currency) => ipcRenderer.invoke('financeone:stock-lookup',{symbol,date,currency}),
  isDesktop: true
});
